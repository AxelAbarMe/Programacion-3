package avi.ui;

import avi.Servicios.GeminiService;

//Imports base de Javafx
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;

//Imports funcionales para eventos de red / http
import javafx.application.Platform; //Conexion multiplataforma

//Imports de controles
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;

public class InterfazChatController {

    @FXML private Button btnVolverChat;
    @FXML private Button btnenviar;
    @FXML private Label lbEtiquetaChat;
    @FXML private TextField txtCampoTexto;
    @FXML private TextArea txtHistorialConversacion;
    @FXML private Label lbAvisoSesion;

    private final GeminiService geminiService = new GeminiService();

    @FXML
    private void initialize(){
        btnVolverChat.setOnAction(event -> {
            try{
                Parent raiz = FXMLLoader.load(getClass().getResource("InterfazHistorial.fxml"));
                Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
                stage.getScene().setRoot(raiz);
            }catch(Exception error){
                error.printStackTrace();
            }
        });

        if(LoginViewController.sesionIniciada){
            lbAvisoSesion.setText("Sesión iniciada!");
        }
        else { lbAvisoSesion.setText("Para guardar la conversación, inicia sesión");}
        btnenviar.setOnAction(event -> enviarMensaje());
        txtCampoTexto.setOnAction(event -> enviarMensaje());
        lbEtiquetaChat.setText("Esperando...");
    }

    private void enviarMensaje(){
        String texto = txtCampoTexto.getText().trim();
        if(texto.isEmpty()) return;
        txtHistorialConversacion.appendText("Tú: " + texto + "\n");
        lbEtiquetaChat.setText("Pregunta recibida...");
        txtCampoTexto.clear();
        txtCampoTexto.setDisable(true);
        btnenviar.setDisable(true);

        //Hilos para poder ejecutar nuevas tareas sin tener que cerrar la tarea previa
        Thread hiloIA = new Thread(() -> { // () Dice que va a ejecutar algo que no es de la App
            try{
                lbEtiquetaChat.setText("Pensando...");
                String respuesta = geminiService.enviarMensaje(texto);
                Platform.runLater(() -> {
                    txtHistorialConversacion.appendText("AVI: " + respuesta + "\n");
                    habilitarCampoTexto();
                });
            } catch (Exception error){
                Platform.runLater(() -> {
                    txtHistorialConversacion.appendText("Error: " + error.getMessage() + "\n");
                    habilitarCampoTexto();
                });
            }
        }); //Multifunción

        hiloIA.setDaemon(true);
        hiloIA.start();
    }
    private void habilitarCampoTexto(){
        txtCampoTexto.setDisable(false);
        btnenviar.setDisable(false);
        txtCampoTexto.requestFocus();
        lbEtiquetaChat.setText("Esperando...");
    }
}
