package avi.Servicios;

import avi.DTO.UsuarioDTO;
import avi.Logica.UsuarioLogica;

public class UsuarioService {
    UsuarioLogica userLogica = new UsuarioLogica();

    public int registrarUsuario(UsuarioDTO user){
        return userLogica.registrarUsuario(user);
    }
}
