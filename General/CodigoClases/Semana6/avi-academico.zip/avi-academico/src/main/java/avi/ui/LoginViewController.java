package avi.ui;

import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;

//Imports de controles
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;

public class LoginViewController {
    //Manejo usuario y contraseña

    private static final String USUARIO_VALIDO = "admin";
    private static final String CONTRASENA_VALIDA = "1234";

    //Almacenar inicio de sesión en variable bandera.

    public static Boolean sesionIniciada = false;

    @FXML private TextField txtUsuario;
    @FXML private PasswordField pwdClave;
    @FXML private Button btnIngresar;
    @FXML private Button btnCancelar;
    @FXML private Label lblEtiquetaError;

    @FXML
    private void initialize(){
        btnIngresar.setOnAction(this::IntentarIngresar);
        btnCancelar.setOnAction(event -> cambiarPantalla(event,"InterfazInicio.fxml"));
    }

    private void IntentarIngresar(ActionEvent event){
        String usuario = txtUsuario.getText().trim();
        String clave = pwdClave.getText().trim();
        if (usuario.equals(USUARIO_VALIDO) && clave.equals(CONTRASENA_VALIDA)){ sesionIniciada = true; cambiarPantalla(event, "InterfazHistorial.fxml");}
        else { lblEtiquetaError.setText("Usuario o contraseña incorrecta");}
    }

    private void cambiarPantalla(ActionEvent evento, String archivoFxml){
        try{
            Parent raiz = FXMLLoader.load(getClass().getResource(archivoFxml));
            Stage stage = (Stage)((Node) evento.getSource()).getScene().getWindow();
            stage.getScene().setRoot(raiz);
        }
        catch(Exception error)
        {
            error.printStackTrace();
        }
    }

    // Ejemplo contraseña guarda encriptada con hash 256 -- M@p@ch3

    // Se puede hacer sumando O!s!fk6
    // Mapeo de llave contra valores
    //  llave | valor | clave | pos
    //   u23  | tr5%  | m     | 130
    //  Al cambiarlo a un valor hash 256 y M@p@ch3 -> 28
    // Lo que sucede es que rellena con caracteres aleatorios y hash selecciona de forma aleatoria cada vez que se genera.

}
