package avi.Datos;

import avi.DTO.UsuarioDTO;

public class UsuarioDatos {
    private String rutaArchivo;

    public UsuarioDatos() {}

    public UsuarioDatos(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public void serializar(){
        //TODO: Este metodo deberia convertir los datos de la aplicacion para almacenarlos en el xml o json
        //Nota: Este metodo no aplica para bases de datos, porque el proceso de serializacion, se hace automaticamente al llamadr al motor de BD
    }
    public void desserializar(){
        //TODO: Este metodo deberia convertir los datos del archivo xml o json para integrarlos a la aplicacion de java
        //Nota: Este metodo no aplica para bases de datos, porque el proceso de desserializacion, se hace automaticamente al llamadr al motor de BD
    }
    public void iniciarSesion(String user, String pwd){
        //Object resultado = BaseDeDatos.VerificarInicioSesion(user,pwd)
        //return resultado
    }
}
