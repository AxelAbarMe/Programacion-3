package avi.Logica;

import avi.DTO.UsuarioDTO;
import avi.Datos.UsuarioDatos;

import java.lang.reflect.Array;

public class UsuarioLogica {
    public UsuarioLogica() {}

    public int registrarUsuario(UsuarioDTO user){
        if(user.getIdUsuario() > 0) {return 1;}
        return 0;
    }
    public void actualizarPassword(int id, String pwd){

    }
    public void actualizarEstado(int id, int est){

    }
    public void eliminarUsuario(int id){

    }
    public UsuarioDTO buscarUsuarioPorUsername(String nombreUsuario){

        return new UsuarioDTO();
    }

    public UsuarioDTO buscarUsuarioPorId(int id){
        UsuarioDatos userDatos = new UsuarioDatos();
        userDatos.serializar();


        return new UsuarioDTO();
    }

    //Esto nos va a devolver una colección cualquiera
    public void buscarUsuariosPorEstado(int est){

    }
    public void iniciarSesion(String user, String pwd){
        UsuarioDatos usuarioDatos = new UsuarioDatos();
        //var resultado = usuarioDatos.iniciarSesion(user,pwd);
        //if (resultado==true)
        // -> InicioSesion
        //else
        // -> Error en el inicio de sesion
    }
}
