package avi.DTO;

public class UsuarioDTO {
    private int idUsuario;
    private String usuario;
    private String password;
    private int estado;

    public UsuarioDTO() {
    }

    public UsuarioDTO(int idUsuario, String usuario, String password, int estado) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.password = password;
        this.estado = estado;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
}
