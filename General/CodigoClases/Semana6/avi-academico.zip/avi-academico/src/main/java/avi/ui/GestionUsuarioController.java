package avi.ui;

import avi.DTO.UsuarioDTO;

public class GestionUsuarioController {

    public void iniciarSesion(UsuarioDTO user){
        //var resultado = usuarioService.inicarSesion(usuario.getNombre(). usuario.getPassword());
        //if resultado == correcto
        // usuario -> inicio de sesion exitoso, redirigiendo a pantalla principal
        //else
        // usuario -> ocurrio un error en el inicio de sesion, verifique los datos e intente de nuevo
    }
}
